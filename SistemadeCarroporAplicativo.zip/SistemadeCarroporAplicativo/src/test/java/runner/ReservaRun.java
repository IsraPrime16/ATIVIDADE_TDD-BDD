/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package runner;
import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
/**
 *
 * @author aluno
 */


@RunWith(Cucumber.class)
@CucumberOptions(
    features = "src/test/resources/features/reserva.feature",
    glue = "steps",
    plugin = {"pretty", "html:target/cucumber-reports"},
    monochrome = true
)
public class ReservaRun {
}
